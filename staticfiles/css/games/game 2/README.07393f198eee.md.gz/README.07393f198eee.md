Javascript implementation of Flappy Bird game.

Demo: [http://fatiherikli.github.io/flappybird](http://fatiherikli.github.io/flappybird)
